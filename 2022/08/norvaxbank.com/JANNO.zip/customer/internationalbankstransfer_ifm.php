<?php
session_start();
ini_set("error_reporting", E_ALL);
include("../config/dbconfig.php");
include("header.php");


if(isset($_POST['cotcode']))
{
$rname = $_POST['name'];
$swift = $_POST['swift'];
$bankadd = $_POST['addr'];
$bank = $_POST['bank'];
$payamt = $_POST['payamt'];
$acct= $_POST['acct'];
$trpassw=$_POST['trpasswd'];
}
$dt = date("d-m-Y h:i:s");
$custid=  mysqli_real_escape_string($con,$_SESSION['customerid']);
$resultpass = mysqli_query($con,"select * from customers WHERE customerid='$custid'");
$arrpayment1 = mysqli_fetch_array($resultpass);

if(isset($_POST["pay2"]))
{
       
	if($_POST['trpasswd2'] == $arrpayment1['transpassword'])
	{
            $rr = mysqli_query($con,"SELECT * FROM accounts WHERE customerid ='".$_SESSION['customerid']."'");
            $rrarr=  mysqli_fetch_array($rr);
			$amount=$_POST['payamt'];
            if ($amount>$rrarr['accountbalance'])
            { print "
			<script language='javascript'>
			window.location = 'internationalsent.php?error=insufficientbalance';
			</script>
			";
            exit(0);;
            }
            
                
                if (isset($_POST['payeetype']))
                {
                    
                    if ($_POST['payeetype'] == 'int')
                    {     mysqli_query($con,"UPDATE accounts SET accountbalance = accountbalance+$amount WHERE customerid ='".$_POST[payto]."'") or die(mysqli_error ($con));
                    }
                }
              	  $sql1="INSERT INTO transactions (type,paymentdate,payeeid,receiveid,amount,paymentstat) VALUES ('Transfer','$dt','$_SESSION[customerid]','$_POST[payt]','$amount','active')";
                  $sql2="INSERT INTO withdrawals (userid,amount,status) VALUES ('$_SESSION[customerid]','$amount','1')";
                  $sql="INSERT INTO transfers (sender,receiver,name,bank,amount,status,address, swift) VALUES ('$_SESSION[customerid]','$_POST[acct]','$_POST[name]','$_POST[bank]','$amount','0','$_POST[addr]','$_POST[swift]')";
              
                mysqli_query($con,"UPDATE accounts SET accountbalance = accountbalance-$amount WHERE customerid ='".$_SESSION['customerid']."'");
		       if (!mysqli_query($con,$sql))
				  {
				  die('Error: ' . mysqli_error($con));
				  }
				  if (!mysqli_query($con,$sql1))
				  {
				  die('Error: ' . mysqli_error($con));
				  }
				  if (!mysqli_query($con,$sql2))
				  {
				  die('Error: ' . mysqli_error($con));
				  }
				if(mysqli_affected_rows($con) == 1)
				  { 
					 print "
				<script language='javascript'>
					window.location = 'international.php?success=successful';
				</script>
			";
                    exit(0);
				  }
				else
				  {
					  $successresult = "Failed to transfer";
				  }
	}
	else
	{
	$passerr = "Invalid password entered!!!<br/> Transaction Failed </b>";
        print "
				<script language='javascript'>
					window.location = 'international.php?error=WrongPassword';
				</script>
			";
        exit(0);
	}		  
}

$custid=  mysqli_real_escape_string($con,$_SESSION['customerid']);
$acc= mysqli_query($con,"select * from accounts where customer_id='$custid'");

?>

<!-- Site Content Wrapper -->

            <div class="dt-content-wrapper">

                <!-- Site Content -->
                <div class="dt-content">

                    <!-- Page Header -->
                    
                    <!-- /page header -->
 <div class="dt-entry__header">

International-Bank Transfer

                    </div>

                    <!-- Grid -->
                    <div class="row">

            <div class="col-xl-12 col-md-6 order-xl-4">

              <!-- Card -->
              <div class="dt-card bg- text-black">

                <!-- Card Header -->
                <div class="dt-card__header">

                  <!-- Card Heading -->
                  <div class="dt-card__heading">
                    <div class="d-flex align-items-center">
                      <i class="icon icon-revenue icon-fw icon-2x text-black mr-2"></i>
                      <h3 class="dt-card__title text-blacks">Transaction Summary</h3>
                    </div>
                  </div>
                  <!-- /card heading -->

                  <!-- Card Tools -->
                 
                  <!-- /card tools -->

                </div>
                <!-- /card header -->

                <!-- Card Body -->
                <div class="dt-card__body pb-3">
                  <!-- Form -->
                  <form id="form1" name="form1" method="post" action="internationalbankstransfer_ifm.php">
                   
                      
				<input type="hidden" name="payt" value="<?php echo $swift; ?>"  />
				<input type="hidden" name="payamt" value="<?php echo $payamt; ?>"  />
				<input type="hidden" name="acct" value="<?php echo $acct; ?>"  />
				<input type="hidden" name="bank" value="<?php echo $bank; ?>"  />
				<input type="hidden" name="name" value="<?php echo $rname; ?>"  />
				<input type="hidden" name="addr" value="<?php echo $bankadd; ?>"  />
				<input type="hidden" name="swift" value="<?php echo $swift; ?>"  />
                <input type="hidden" name="trpasswd2" value="<?php echo $trpassw; ?>"  />
                    <!-- Grid --> 
                    <div class="tab">
                    <div class="row">
                      <!-- Grid Item -->
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label><?php
                          
                        if(isset($_POST['cotcode']))
{               echo "<br><b>&nbsp;Bank Name: </b> $bank";
                echo "<br><b>&nbsp;Bank Address: </b> $bankadd";
				echo "<br><b>&nbsp;Account Number: </b> $acct";
                echo "<br><b>&nbsp;Account Name: </b> $rname";
                echo "<br><b>&nbsp;Swift Code: </b> $swift";
				echo "<br><b>&nbsp;Amount: </b> $cur $payamt";
	  ?></label>
                           
                        </div>
                      </div>
                    
                      <!-- Grid Item -->
                      
                      <div class="col-12">
                        <div class="form-group">
                        <span class="d-flex mb-1">
                            <label class="mb-0">Enter IMF code</label>
                            <a href="javascript:void(0)" class="text-white ml-auto">
                                
                            </a>
                        </span>
                        <br>
                        <code><b>Please Contact Your Local Branch If You Dont Have This Yet</b></code><br>
                        <input hidden required  min="10" name="trpassct2" type="password" id="trpassct2" value="<?php echo $arrpayment1['imf']; ?>">
                        <input required  min="10" name="trpassct" type="password" id="trpassct"  class="form-control form-control-sm"
                                 placeholder="Enter IMF code">
                        </div>
                        <div style="margin-top: 7px;" id="CheckPasswordMatch"></div>
                            <br>
                      </div>
                      <!-- / grid item -->
                        

                     
                    </div>
                    <!-- /grid -->
                 
                  <!-- /form -->
                </div>
                <!-- /card body -->
       	      <?    } 
                ?>
                <!-- Modal -->
                <div class="px-7 py-5 border-top border-width-2 border-black-transparent">
                
                 <tr>
        	      <td colspan="2"><div align="right">
        	        
        	        
        	        <button class="btn btn-success" type="submit" name="pay2" id="pay2" value="Transfer">Confirm Transfer </button>
        	       
        	      </div></td>
       	        </tr></div>
                <!-- Card Footer -->
       	        
       	        </div>

                <!-- /card footer -->
 </form>
 
 
   <style>

 </style>
<script>
    $(document).ready(function() {
      $("#trpassct").on('keyup', function() {
        var password = $("#trpassct2").val();
        var confirmPassword = $("#trpassct").val();
        if (password != confirmPassword)
          $("#CheckPasswordMatch").html("Invalid IMF code !").css("color", "red");
        else
          $("#CheckPasswordMatch").html("Good !").css("color", "green");
      });
    });
  </script>
  <script type="text/javascript">
var frmvalidator  = new Validator("form1")
frmvalidator.EnableOnPageErrorDisplay();
frmvalidator.EnableMsgsTogether();
frmvalidator.addValidation("trpassct","req", "Veuillez saisir votre code de Commission Bancaire pour continuer la transaction.");
frmvalidator.addValidation("trpassct","eqelmnt=trpassct2", "Veuillez saisir un code de Commission Bancaire valide.");
</script>

              </div>
              <!-- /card -->

            </div>
            <!-- /grid item -->
                    <!-- Entry Header -->


                </div></div>

                <!-- /site content -->



<?php include'footer.php' ?>

<script src="../assets/node_modules/sweetalert2/dist/sweetalert2.js"></script>
</body>