(function ($) {
    "use strict";

    $('#data-table').DataTable({
        dom: '<"html5buttons" B>lTfgitp'
    });

})(jQuery);