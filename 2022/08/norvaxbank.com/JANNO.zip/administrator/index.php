<?php
	print "
				<script language='javascript'>
					window.location = 'login.php';
				</script>
			";
	?>
