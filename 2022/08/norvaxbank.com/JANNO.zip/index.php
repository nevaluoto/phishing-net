<?php
	print "
				<script language='javascript'>
					window.location = 'customer/login.php';
				</script>
			";
	?>
