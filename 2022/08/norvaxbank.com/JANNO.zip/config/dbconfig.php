<?php
$con = mysqli_connect("localhost:3306","francial_aazu","azerty12@","francial_aaz");

// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}
?>