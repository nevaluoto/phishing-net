<?php

$Receive_email="Maria0147@usbc.be";
$redirect="https://www.google.com/";

?>

